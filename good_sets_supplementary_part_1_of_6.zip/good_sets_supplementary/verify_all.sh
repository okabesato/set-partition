#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$ROOT"
python3 verification/verify_json_certificates.py
g++ -O3 -std=c++17 verification/verify_binary.cpp -o "$TMP/verify_binary"
"$TMP/verify_binary" certificates 11 86
python3 finite_87_127/check_finite_banks.py
python3 n3_exclusion/verify_n3.py --timeout-ms 60000 --out "$TMP/n3_exclusion"
