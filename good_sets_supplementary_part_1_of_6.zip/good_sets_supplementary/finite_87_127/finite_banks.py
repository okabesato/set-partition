from __future__ import annotations
import json
from pathlib import Path
from dataclasses import dataclass

@dataclass
class Construction:
 n: int
 W: int
 K: int
 M: int
 L: int
 s0: int
 m: int
 h: int
 F: int
 V: int
 denominations: list[int]
 banks: list[list[tuple[int, int]]]
 high: list[int]
 low: list[int]
 padding: list[int]
 A: list[int]
 S: int
 bank_of: dict[int, int]

def build(n,W,K):
 M=1<<K;c=(n+W-1)//W
 if c<2:return None
 D=[1<<j for j in range(W.bit_length())]+[W]*(c-2)+[n*(1<<j) for j in range(K)]
 L=len(D);s0=L+1;m=s0+W;h=n-2*L-W-1;P=n*(W+1)+1
 if h<2 or m>=n:return None
 used=set();banks=[];bo={};first=0
 for b in range(n):
  bank=[]
  for d in D:
   t=first
   while True:
    lo=1+n*s0+n*n*t;hi=lo+n*d
    if lo not in used and hi not in used:break
    t+=1
   bank.append((lo,hi));used.update([lo,hi]);bo[lo]=bo[hi]=b
   while 1+n*s0+n*n*first in used:first+=1
  banks.append(bank)
 extra=n-s0;pad=[];t=4*n*L+1
 for _ in range(P):
  eps=min(W,extra);extra-=eps
  while True:
   a=1+n*(s0+eps)+n*n*t;t+=1
   if a not in used:break
  used.add(a);pad.append(a)
 high=[1+n*s0+n*n*(M+5*n*n+j) for j in range((n-1)*h+1)]
 low=[1+n*s0+n*n*(M//2+5*n*n+j) for j in range(h-1)]
 if used.intersection(high) or used.intersection(low) or set(high).intersection(low):return None
 A=sorted([*used,*high,*low]);S=sum(A)
 if len(A)!=n*n+1 or S%(n*n)!=1:return None
 return Construction(n,W,K,M,L,s0,m,h,n*sum(D),n*n*M,D,banks,high,low,pad,A,S,bo)

def certify(c):
 n=c.n;h=c.h;F=c.F;up=[sum(v for u,v in b) for b in c.banks]
 hl=sum(sorted(c.high)[:h]);hu=sum(sorted(c.high)[-h:]);pads=sorted(c.padding)
 rec=[]
 for s in range(c.s0,c.m+1):
  xs=[a for a in c.A if ((a-1)//n)%n==s]
  if not xs:continue
  p=c.m-s
  ul=hl+min(up)+sum(pads[:p]);uu=hu+max(up)+(sum(pads[-p:]) if p else 0)
  # Must have U-T >=0 and <=F for all x and any available bank.
  dl=n*ul-c.S+min(xs);du=n*uu-c.S+max(xs)
  if dl<0 or du>n*F:return None
  rec.append([s,dl,n*F-du])
 return rec

