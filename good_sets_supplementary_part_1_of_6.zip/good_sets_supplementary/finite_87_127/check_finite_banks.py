#!/usr/bin/env python3
"""Check finite sufficient-condition certificates, using exact integers only.

This verifies a uniform-in-the-deleted-element criterion for 87 <= n <= 127.
It does not perform or trust any subset-sum search.
"""
from pathlib import Path
from collections import Counter
import json
from finite_banks import build

def require(ok,message):
    if not ok: raise ValueError(message)

def verify(c):
    n=c.n;A=c.A;S=sum(A);L=c.L;h=c.h;m=c.m
    require(len(A)==n*n+1 and len(set(A))==len(A) and min(A)>0,'set')
    require(S==c.S and S%(n*n)==1,'total residue')
    require(len(c.banks)==n and all(len(b)==L for b in c.banks),'banks')
    require(h+L+m==n and h>0 and 1<=c.s0<=m<n,'sizes and labels')
    resources=[v for bank in c.banks for pair in bank for v in pair]+c.high+c.low+c.padding
    require(Counter(resources)==Counter(A),'resource coverage and disjointness')
    require(len(c.high)>=(n-1)*h+1,'high resource')
    require(len(c.padding)>=(n-1)*(m-c.s0)+1,'padding resource')
    D=None
    for bank in c.banks:
        ds=[]
        for u,v in bank:
            require(v>u and (v-u)%n==0,'pair difference')
            ds.append((v-u)//n)
        require(D is None or ds==D,'bank step list')
        D=ds
    reach=0
    for d in sorted(D):
        require(1<=d<=reach+1,'subset-sum interval')
        reach+=d
    F=n*reach
    require(F==c.F,'switching capacity')
    labels={}
    for a in A:
        require(a%n==1,'common residue')
        s=((a-1)//n)%n
        require(c.s0<=s<=m,'label interval')
        labels.setdefault(s,[]).append(a)
    highs=sorted(c.high);pads=sorted(c.padding)
    bsum=[sum(v for u,v in bank) for bank in c.banks]
    rows=[]
    for s,xs in sorted(labels.items()):
        p=m-s
        lower=sum(highs[:h])+min(bsum)+sum(pads[:p])
        upper=sum(highs[-h:])+max(bsum)+(sum(pads[-p:]) if p else 0)
        lower_margin=n*lower-S+min(xs)
        upper_margin=n*F-(n*upper-S+max(xs))
        require(lower_margin>=0 and upper_margin>=0,'switching interval bounds')
        rows.append([s,lower_margin,upper_margin])
    require(max(A)<3*n**6,'polynomial bound 3 n^6')
    return rows

if __name__=='__main__':
    records=json.loads(Path(__file__).with_name('parameters_87_127.json').read_text())
    require([r['n'] for r in records]==list(range(87,128)),'parameter coverage')
    for r in records:
        c=build(r['n'],r['W'],r['K'])
        require(c is not None,'construction failed')
        rows=verify(c)
        require(rows==r['margins'],'recorded inequalities disagree')
        print(f"VERIFIED n={c.n}: all label classes, both interval bounds; minimum margin={min(min(v[1:]) for v in rows)}")
    print('ALL 41 PARAMETERS VERIFIED; criterion covers EVERY deletion, not a sample.')
