# Supplementary Materials

## A problem on equal-sum partitions after deletion

This supplementary package is split into six ZIP files because of the upload-size
limit. Download **all six parts** and extract each one into the same parent
directory. Every part uses the same top-level folder, `good_sets_supplementary/`,
so the files will be merged into one directory tree.

## Parts

| Part | Certificate files |
|---|---|
| `good_sets_supplementary_part_1_of_6.zip` | `n4` through `n55`, plus all common verification files |
| `good_sets_supplementary_part_2_of_6.zip` | `n56` through `n65` |
| `good_sets_supplementary_part_3_of_6.zip` | `n66` through `n72` |
| `good_sets_supplementary_part_4_of_6.zip` | `n73` through `n77` |
| `good_sets_supplementary_part_5_of_6.zip` | `n78` through `n81` |
| `good_sets_supplementary_part_6_of_6.zip` | `n82` through `n86` |

The certificate files cover every order from 4 through 86. The non-certificate
files (checkers, SMT inputs, finite-parameter data, and this README) are included
in Part 1 only.

## Contents after extraction

```text
good_sets_supplementary/
  README.md
  SHA256SUMS.txt
  verify_all.sh
  certificates/
    n4.json ... n10.json
    n11.bin ... n86.bin
  n3_exclusion/
    verify_n3.py
    expected_results.json
    smtlib/
      case_2_1_7.smt2
      case_4_0_6.smt2
      case_5_1_4.smt2
      case_7_0_3.smt2
  verification/
    verify_json_certificates.py
    verify_binary.cpp
  finite_87_127/
    finite_banks.py
    check_finite_banks.py
    parameters_87_127.json
```

## What the materials verify

- **Orders 4--10:** explicit JSON partitions for every deletion.
- **Order 3:** four finite linear-real-arithmetic instances used in the
  nonexistence argument. All four must return `unsat`; `sat`, `unknown`, or
  a timeout is inconclusive.
- **Orders 11--86:** complete binary partition certificates for every deletion.
- **Orders 87--127:** exact checks of the hypotheses of the sufficient
  switching-interval criterion proved in the paper. The criterion covers
  every deletion at each of these orders.
- **Orders n >= 128:** handled by the uniform construction in the paper;
  no finite certificate is needed.

The checkers use exact integer arithmetic for partition certificates. They do
not invoke the search heuristics that originally found the witnesses.

## Requirements

- Python 3.10 or later.
- A C++17 compiler.
- Z3 4.13.3.0 (Python package `z3-solver`) or a compatible installed Z3
  shared library for the order-3 check.

Install the Python dependency with:

```bash
python -m pip install z3-solver==4.13.3.0
```

## Reproduce all checks

Run these commands from the directory containing `README.md`, after extracting
all six parts:

```bash
python verification/verify_json_certificates.py
g++ -O3 -std=c++17 verification/verify_binary.cpp -o verification/verify_binary
verification/verify_binary certificates 11 86
python finite_87_127/check_finite_banks.py
python n3_exclusion/verify_n3.py --timeout-ms 60000 --out n3_exclusion/recheck_output
```

Or run the shell wrapper:

```bash
bash verify_all.sh
```

The order-3 script exits successfully only if all four cases return `unsat`.
The reference results are recorded in `n3_exclusion/expected_results.json`;
rerunning the script regenerates the instances and checks them again.

## Integrity

`SHA256SUMS.txt` lists SHA-256 hashes for every file in the merged directory
except the checksum file itself. Run:

```bash
sha256sum -c SHA256SUMS.txt
```

This archive is supplementary verification material. The mathematical
arguments for the switching criterion and the uniform construction are given
in the accompanying paper.
