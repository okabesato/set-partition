#!/usr/bin/env python3
"""Verify all JSON partition certificates for orders 4 through 10.

Uses only Python's standard library and exact integer arithmetic.
"""
from collections import Counter
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CERT = ROOT / "certificates"

SMALL = {
    4: [1, 5, 9, 17, 33, 37, 49, 57, 65, 73, 97, 101, 113, 117, 129, 197, 213],
    5: [1, 11, 26, 36, 51, 61, 76, 81, 86, 101, 106, 131, 151, 156, 161, 176, 206, 226, 276, 301, 336, 351, 376, 401, 406, 436],
}
PROGRESSIONS = {
    6: ((0, 1, 2), (13, 12, 12)),
    7: ((0, 1, 2), (17, 17, 16)),
    8: ((0, 1, 2), (22, 22, 21)),
    9: ((1, 2, 3), (34, 16, 32)),
    10: ((1, 2, 3), (34, 35, 32)),
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def expected_set(n: int) -> list[int]:
    if n in SMALL:
        return SMALL[n]
    labels, counts = PROGRESSIONS[n]
    return sorted(
        1 + n * s + n * n * j
        for s, count in zip(labels, counts)
        for j in range(count)
    )


def check(n: int) -> int:
    data = json.loads((CERT / f"n{n}.json").read_text(encoding="utf-8"))
    A = expected_set(n)
    S = sum(A)
    require(len(A) == n * n + 1 and len(set(A)) == len(A), f"n={n}: cardinality/distinctness")
    require(all(type(a) is int and a > 0 for a in A), f"n={n}: positivity")
    require(max(A) < 3 * n**6, f"n={n}: claimed 3 n^6 bound")
    require(data["n"] == n and data["A"] == A, f"n={n}: metadata")
    if "S" in data:
        require(data["S"] == S, f"n={n}: total-sum metadata")
    if "labels" in data:
        require(data["labels"] == list(PROGRESSIONS[n][0]), f"n={n}: label metadata")
    if "counts" in data:
        require(data["counts"] == list(PROGRESSIONS[n][1]), f"n={n}: count metadata")
    partitions = data["partitions"]
    require(set(partitions) == {str(x) for x in A}, f"n={n}: deletion coverage")
    for x in A:
        groups = partitions[str(x)]
        require(len(groups) == n and all(groups), f"n={n}, x={x}: group count/nonempty")
        flat = [a for group in groups for a in group]
        require(all(type(a) is int for a in flat), f"n={n}, x={x}: noninteger")
        require(Counter(flat) == Counter(a for a in A if a != x), f"n={n}, x={x}: coverage/disjointness")
        require(all(n * sum(group) == S - x for group in groups), f"n={n}, x={x}: unequal sums")
    print(f"VERIFIED n={n}: all {len(A)} deletions; S={S}; max(A)={max(A)}")
    return len(A)


if __name__ == "__main__":
    total = sum(check(n) for n in range(4, 11))
    print(f"TOTAL VERIFIED: {total} deletions for n=4,...,10")
