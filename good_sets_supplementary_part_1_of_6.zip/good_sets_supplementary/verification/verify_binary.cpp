// Independent exact verifier. It does not call any search or optimization code.
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
int get16(ifstream& f){int a=f.get(),b=f.get();if(a<0||b<0)throw runtime_error("truncated certificate");return a+256*b;}
int main(int argc,char**argv){
 string dir=argc>1?argv[1]:"certificates";int lo=argc>2?stoi(argv[2]):11,hi=argc>3?stoi(argv[3]):86;long long total=0;
 for(int n=lo;n<=hi;++n){
  ifstream f(dir+"/n"+to_string(n)+".bin",ios::binary);if(!f)throw runtime_error("missing file");char magic[4];f.read(magic,4);if(string(magic,4)!="GDS1"&&string(magic,4)!="GDS2")throw runtime_error("bad magic");bool v2=magic[3]=='2';int nn=get16(f),N=get16(f);if(nn!=n||N!=n*n+1)throw runtime_error("bad header");
  int h=n*n/3;vector<int>cnt=n%3?vector<int>{h+1,h+2,h-1}:vector<int>{h,h+3,h-2};vector<long long>A;long long S=0;
  for(int s=1;s<=3;++s)for(int j=0;j<cnt[s-1];++j){long long a=1LL+n*s+1LL*n*n*j;if(a<=0)throw runtime_error("not positive");A.push_back(a);S+=a;}
  auto sorted=A;sort(sorted.begin(),sorted.end());if(adjacent_find(sorted.begin(),sorted.end())!=sorted.end())throw runtime_error("repeated values");if(sorted.back()>=3LL*n*n*n*n*n*n)throw runtime_error("claimed 3 n^6 bound failed");
  vector<int>owner(N,255),seen(N,0);int done=0;
  while(f.peek()!=EOF){int del=get16(f),changes=get16(f);if(del>=N||seen[del]++)throw runtime_error("bad or repeated deletion");
   if(v2&&changes==65535){for(int i=0;i<N;++i){owner[i]=f.get();if(owner[i]<0)throw runtime_error("truncated full state");}}
   else {if(changes>N)throw runtime_error("bad delta count");vector<int>changed(N);for(int k=0;k<changes;++k){int i=get16(f),g=f.get();if(i>=N||g<0||changed[i]++)throw runtime_error("bad change");owner[i]=g;}}
   vector<long long>sums(n);vector<int>sizes(n);
   for(int i=0;i<N;++i){if(i==del){if(owner[i]!=255)throw runtime_error("deleted element used");continue;}int g=owner[i];if(g<0||g>=n)throw runtime_error("missing element or bad group");sums[g]+=A[i];++sizes[g];}
   for(int g=0;g<n;++g)if(!sizes[g]||n*sums[g]!=S-A[del])throw runtime_error("invalid partition");++done;
  }
  if(done!=N||count(seen.begin(),seen.end(),1)!=N)throw runtime_error("not all deletions covered");total+=done;cout<<"VERIFIED n="<<n<<" all "<<done<<" deletions\n";
 }
 cout<<"TOTAL VERIFIED "<<total<<" deletions\n";
}
