#!/usr/bin/env python3
"""Computer-assisted exclusion of 10 distinct positive integer good sets (n=3).

Usage:
    python -m pip install z3-solver
    python verify_n3.py

The script generates finite disjunctions of homogeneous linear equalities.
Variables are positive reals with sum 1; no upper bound on the original
integers is assumed. The mathematical reductions are in README.md.

Only four UNSAT results establish the computational step. UNKNOWN is
explicitly reported as inconclusive. The Linux shared Z3 library is a
fallback when the Python package is not installed.
"""
from __future__ import annotations
import argparse
import ctypes
import ctypes.util
import itertools
import json
from pathlib import Path
from typing import Iterator

CASES = ((7, 0, 3), (4, 0, 6), (5, 1, 4), (2, 1, 7))
N = 10
Group = tuple[int, ...]
Partition = tuple[Group, Group, Group]


def make_problem(counts: tuple[int, int, int]) -> tuple[str, list[int]]:
    """Return SMT-LIB declarations/assertions and partition-option counts."""
    q = [label for label, count in enumerate(counts) for _ in range(count)]
    classes = [[j for j in range(N) if q[j] == label] for label in range(3)]

    def tails(group: Group) -> list[int]:
        # If a class is x_0 < ... < x_m, write its values as positive
        # increments. These are the coefficients of those increments.
        return [sum(j in group for j in cls[k:])
                for cls in classes for k in range(len(cls))]

    def strictly_dominates(g: Group, h: Group) -> bool:
        u, v = tails(g), tails(h)
        return u != v and (all(x >= y for x, y in zip(u, v))
                          or all(x <= y for x, y in zip(u, v)))

    def partitions(i: int) -> Iterator[Partition]:
        sizes = ((3, 3, 3), (1, 4, 4), (2, 2, 5))[q[i]]
        remaining = set(range(N)) - {i}
        for g0 in itertools.combinations(sorted(remaining), sizes[0]):
            rest = remaining - set(g0)
            for g1 in itertools.combinations(sorted(rest), sizes[1]):
                g2 = tuple(sorted(rest - set(g1)))
                # Canonical order only among equally sized groups.
                if sizes[0] == sizes[1] and g0 > g1:
                    continue
                if sizes[1] == sizes[2] and g1 > g2:
                    continue
                groups = (g0, g1, g2)
                # Necessary congruence from the original integers modulo 9.
                residues = [(sum(q[j] for j in g)
                             - (len(g) - q[i]) // 3) % 3 for g in groups]
                if not (residues[0] == residues[1] == residues[2]):
                    continue
                # A componentwise dominance inequality makes equality
                # impossible for positive, strictly ordered class values.
                if any(strictly_dominates(groups[k], groups[l])
                       for k in range(3) for l in range(k)):
                    continue
                if q[i] == 1:
                    # The singleton must be the largest element of A.
                    singleton = g0[0]
                    if singleton != classes[q[singleton]][-1]:
                        continue
                yield groups

    def total(group: Group) -> str:
        if len(group) == 1:
            return f"a{group[0]}"
        return "(+ " + " ".join(f"a{j}" for j in group) + ")"

    lines: list[str] = []
    for j in range(N):
        lines.extend((f"(declare-const a{j} Real)", f"(assert (> a{j} 0))"))
    # Sorting within each color class is without loss of generality.
    for cls in classes:
        lines.extend(f"(assert (< a{i} a{j}))" for i, j in zip(cls, cls[1:]))
    for i in range(N):
        for j in range(i):
            if q[i] != q[j]:
                lines.append(f"(assert (not (= a{i} a{j})))")
    lines.append("(assert (= (+ " + " ".join(f"a{j}" for j in range(N)) + ") 1))")
    if counts[1]:
        # The sole deletion with a singleton removes the second-largest.
        i = classes[1][0]
        options = []
        for j in range(N):
            if j == i:
                continue
            clauses = [f"(> a{j} a{i})"]
            clauses.extend(f"(< a{k} a{i})" for k in range(N) if k not in (i, j))
            options.append("(and " + " ".join(clauses) + ")")
        lines.append("(assert (or " + " ".join(options) + "))")

    option_counts = []
    for i in range(N):
        options = []
        for groups in partitions(i):
            options.append("(and " + " ".join(
                f"(= {total(groups[0])} {total(groups[k])})" for k in (1, 2)) + ")")
        option_counts.append(len(options))
        lines.append("(assert (or false " + " ".join(options) + "))")
    return "\n".join(lines), option_counts


class SharedZ3:
    """Minimal fallback interface to the installed Z3 shared library."""
    def __init__(self) -> None:
        name = ctypes.util.find_library("z3")
        if not name:
            raise RuntimeError("Install the Python package: python -m pip install z3-solver")
        self.lib = ctypes.CDLL(name)
        self.lib.Z3_mk_config.restype = ctypes.c_void_p
        self.lib.Z3_mk_context.argtypes = [ctypes.c_void_p]
        self.lib.Z3_mk_context.restype = ctypes.c_void_p
        self.lib.Z3_del_config.argtypes = [ctypes.c_void_p]
        self.lib.Z3_del_context.argtypes = [ctypes.c_void_p]
        self.lib.Z3_eval_smtlib2_string.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        self.lib.Z3_eval_smtlib2_string.restype = ctypes.c_char_p
        self.lib.Z3_get_full_version.restype = ctypes.c_char_p
        self.version = self.lib.Z3_get_full_version().decode()

    def check(self, body: str, timeout_ms: int) -> str:
        config = self.lib.Z3_mk_config()
        context = self.lib.Z3_mk_context(config)
        self.lib.Z3_del_config(config)
        try:
            text = (f"(set-option :timeout {timeout_ms})\n(set-logic QF_LRA)\n"
                    + body + "\n(check-sat)\n")
            response = self.lib.Z3_eval_smtlib2_string(context, text.encode()).decode().strip()
            if response not in ("sat", "unsat", "unknown"):
                raise RuntimeError(f"Unexpected solver response: {response}")
            return response
        finally:
            self.lib.Z3_del_context(context)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeout-ms", type=int, default=60000,
                        help="Per-case resource timeout; 0 means no timeout.")
    parser.add_argument("--out", type=Path, default=Path("verification_output"))
    args = parser.parse_args()
    if args.timeout_ms < 0:
        parser.error("--timeout-ms must be nonnegative")
    args.out.mkdir(parents=True, exist_ok=True)
    try:
        import z3
    except ImportError:
        shared = SharedZ3()
        version = shared.version
        check = shared.check
    else:
        version = z3.get_full_version()
        def check(body: str, timeout_ms: int) -> str:
            solver = z3.SolverFor("QF_LRA")
            solver.set(timeout=timeout_ms)
            solver.from_string(body)
            return str(solver.check())

    print(f"Z3 version: {version}", flush=True)
    records = []
    for counts in CASES:
        body, option_counts = make_problem(counts)
        name = "case_" + "_".join(map(str, counts)) + ".smt2"
        text = (f"(set-option :timeout {args.timeout_ms})\n(set-logic QF_LRA)\n"
                + body + "\n(check-sat)\n")
        (args.out / name).write_text(text, encoding="utf-8")
        result = check(body, args.timeout_ms)
        print(f"{counts}: {result}; options per deletion: {option_counts}", flush=True)
        records.append({"counts": counts, "result": result, "options": option_counts})
    (args.out / "results.json").write_text(
        json.dumps({"z3_version": version, "cases": records}, indent=2), encoding="utf-8")
    if all(record["result"] == "unsat" for record in records):
        print("All four necessary cases are UNSAT. The computational step is complete.")
        return 0
    print("INCONCLUSIVE: not all cases returned UNSAT. No nonexistence claim follows from this run.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
